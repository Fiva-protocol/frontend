# Description

This app allows to observe all active contracts with orders.
This directory is a temporary one, normally /admin page from https://github.com/CryptonFi/ui should be used.

# Setup

-   `yarn`

## Start app

-   `yarn run dev`
